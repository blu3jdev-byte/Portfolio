---
title: "Beam optimization"
summary: "Sizing a beam to carry its load with the least material, worked through in a spreadsheet model."
# TODO: set the real date for this project (YYYY-MM-DD).
date: 2026-01-01
status: Complete
context: "MEEN 305"
tools:
  - Excel
tags:
  - structures
  - optimization
featured: true
links:
  - label: "Optimization spreadsheet"
    href: "https://docs.google.com/spreadsheets/d/1MXYwC6mVWoUV4sz_2Mt9OrreUhDvx5WulCj0N-lqbOg/edit?usp=sharing"
---

## Problem statement

*Replace this section: what had to be designed or optimized, the loads and supports, and the constraints (material, size, deflection limit, cost).*

## Approach

*Replace this section: how you modeled it, the equations you used, and the alternatives you compared.*

For example, a bending stress check can be written inline as $\sigma = \frac{M c}{I}$, or as a display equation:

$$
\delta_{max} = \frac{5 w L^4}{384 E I}
$$

## Solution

*Replace this section: the design you selected and why it beat the other options.*

## Results

*Replace this section: the numbers that matter.*

| Quantity | Value | Limit |
| --- | --- | --- |
| Maximum stress | to add | to add |
| Maximum deflection | to add | to add |

## What I would change

*Replace this section: what you learned and what you would do differently.*
