---
# Copy this file, rename it (e.g. heat-exchanger-redesign.md), and fill it in.
# Files that start with an underscore are NOT published, so this template stays private.

title: "Project title"
summary: "One or two sentences that say what the problem was and what you built."
date: 2026-01-01              # YYYY-MM-DD, used for sorting
status: Complete              # Complete, In progress, or Concept
context: "Course, internship, team, or organization"   # optional
tools:                        # optional
  - SolidWorks
  - MATLAB
tags:                         # optional
  - thermal
  - design
featured: false               # true = shown first on the home page
draft: false                  # true = hidden from the site while you work on it

# Optional cover image (shown on the project page and the project list).
# Put the file in public/images/<project-name>/ and reference it like this:
cover: /images/project-name/cover.jpg
coverAlt: "Describe the image for people who can't see it"

# Optional videos. Use a YouTube or Vimeo link (recommended), or a small file in public/videos/.
videos:
  - src: "https://www.youtube.com/watch?v=XXXXXXXXXXX"
    title: "Demo video"
    caption: "What the viewer is about to see."

# Optional image gallery. Captions are numbered automatically (Figure 1, Figure 2, ...).
gallery:
  - src: /images/project-name/setup.jpg
    alt: "Test fixture with the beam clamped at both ends"
    caption: "Test setup."

# Optional: link papers from src/content/publications by file name (without .md).
papers:
  - iac-2025-lunar-power

# Optional: other links (reports, CAD, code, spreadsheets).
links:
  - label: "Source code"
    href: "https://github.com/blu3jdev-byte/some-repo"
---

## Problem statement

What was wrong or missing, who it affected, and the constraints you had to work within.

## Approach

How you analyzed it. Equations work: inline like $F = ma$, or as a block:

$$
\sigma = \frac{M c}{I}
$$

## Solution

What you designed or built, and why it beat the alternatives.

## Results

The measured or calculated outcome. Tables work too.

| Quantity | Target | Result |
| --- | --- | --- |
| Example | 10 | 9.4 |

You can also place images inside the text. Use a root path and the site adds the base path for you:

![Describe the image](/images/project-name/figure.jpg)
