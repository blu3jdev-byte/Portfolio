---
# TODO: confirm the author list, title, and venue match the published paper.
title: "Affordable Modular Multi-Service Power Lunar-System"
authors:
  - "Jonah Pinon"
venue: "International Astronautical Congress (IAC) 2025"
year: 2025
type: "Technical paper"
abstractUrl: "https://iafastro.directory/iac/paper/id/101675/abstract-pdf/IAC-25,B3,IP,17,x101675.brief.pdf?2025-03-28.17:29:08"
---

Paste the paper's abstract here to show a "Read the abstract" toggle on the site. Delete this text to hide the toggle.
