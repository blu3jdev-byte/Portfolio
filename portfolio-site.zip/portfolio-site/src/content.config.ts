import { defineCollection, z } from 'astro:content';
import { glob } from 'astro/loaders';

// Files that start with an underscore (like _TEMPLATE.md) are ignored.
const projects = defineCollection({
  loader: glob({ pattern: '**/[^_]*.md', base: './src/content/projects' }),
  schema: z.object({
    title: z.string(),
    summary: z.string(),
    date: z.coerce.date(),
    status: z.enum(['Complete', 'In progress', 'Concept']).default('Complete'),
    context: z.string().optional(), // course, internship, team, or organization
    tools: z.array(z.string()).default([]),
    tags: z.array(z.string()).default([]),
    cover: z.string().optional(), // e.g. /images/my-project/cover.jpg
    coverAlt: z.string().optional(),
    videos: z
      .array(
        z.object({
          src: z.string(), // YouTube/Vimeo link, or /videos/clip.mp4
          title: z.string().optional(),
          caption: z.string().optional(),
        }),
      )
      .default([]),
    gallery: z
      .array(
        z.object({
          src: z.string(),
          alt: z.string(),
          caption: z.string().optional(),
        }),
      )
      .default([]),
    papers: z.array(z.string()).default([]), // file names (without .md) from src/content/publications
    links: z
      .array(z.object({ label: z.string(), href: z.string() }))
      .default([]),
    featured: z.boolean().default(false),
    draft: z.boolean().default(false),
  }),
});

const publications = defineCollection({
  loader: glob({ pattern: '**/[^_]*.md', base: './src/content/publications' }),
  schema: z.object({
    title: z.string(),
    authors: z.array(z.string()),
    venue: z.string(),
    year: z.number(),
    type: z.string().default('Paper'),
    abstractUrl: z.string().optional(),
    pdf: z.string().optional(), // /papers/file.pdf or an external link
    doi: z.string().optional(), // just the DOI, e.g. 10.1234/abcd
    url: z.string().optional(),
  }),
});

export const collections = { projects, publications };
