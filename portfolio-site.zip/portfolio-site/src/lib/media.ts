// Adds the site's base path (/Portfolio) to local paths. External URLs pass through.
export function url(path: string): string {
  if (/^(https?:)?\/\//.test(path) || path.startsWith('mailto:')) return path;
  const base = import.meta.env.BASE_URL.replace(/\/$/, '');
  return base + (path.startsWith('/') ? path : '/' + path);
}

export type VideoInfo =
  | { kind: 'youtube'; id: string }
  | { kind: 'vimeo'; id: string }
  | { kind: 'file'; src: string };

// Accepts a YouTube link, a Vimeo link, or a path to a small video file in /public.
export function videoInfo(src: string): VideoInfo {
  const yt = src.match(
    /(?:youtube\.com\/(?:watch\?v=|embed\/|shorts\/)|youtu\.be\/)([\w-]{11})/,
  );
  if (yt) return { kind: 'youtube', id: yt[1] };
  const vm = src.match(/vimeo\.com\/(?:video\/)?(\d+)/);
  if (vm) return { kind: 'vimeo', id: vm[1] };
  return { kind: 'file', src };
}
